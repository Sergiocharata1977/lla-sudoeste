import { Button } from '@/components/ui/button'
import { ArrowRight } from 'lucide-react'

export function Hero() {
  return (
    <section id="inicio" className="relative min-h-[600px] md:min-h-[700px] flex items-center justify-center bg-gradient-to-br from-white via-gray-50 to-violet-50">
      <div className="absolute inset-0 opacity-10">
        <img
          src="/campo-del-sudoeste-chaco-argentina-atardecer.jpg"
          alt="Sudoeste del Chaco"
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="container mx-auto px-4 relative z-10 text-center">
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-gray-900 mb-6 text-balance">
          Milei Sudoeste Chaco
        </h1>
        <p className="text-xl md:text-2xl text-violet-600 font-bold mb-6 text-balance">
          La libertad avanza desde el interior
        </p>
        <p className="text-lg md:text-xl text-gray-700 mb-8 max-w-3xl mx-auto text-pretty">
          Impulsamos el cambio político, económico y cultural desde el corazón productivo del Chaco.
        </p>
        <Button size="lg" className="bg-violet-600 hover:bg-violet-700 text-white text-lg px-8 py-6">
          Unite al Movimiento
          <ArrowRight className="ml-2" size={20} />
        </Button>
      </div>
    </section>
  )
}
