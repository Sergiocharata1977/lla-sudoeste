'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

export function Join() {
  const [formData, setFormData] = useState({
    name: '',
    city: '',
    phone: '',
    role: ''
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log('Form submitted:', formData)
    // Aquí se implementaría el envío del formulario
  }

  return (
    <section id="sumate" className="py-16 md:py-24 bg-gradient-to-br from-violet-50 to-white">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-5xl font-extrabold text-gray-900 mb-6 text-balance">
              Sumate al Movimiento
            </h2>
            <p className="text-lg md:text-xl text-gray-700 text-pretty">
              Tu aporte es fundamental. El cambio no lo hace un político: lo hacemos todos.
            </p>
          </div>

          <Card className="border-2 border-gray-200">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-gray-900 text-center">
                Formulario de Voluntarios
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-gray-900">Nombre Completo</Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Tu nombre"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="border-2 border-gray-200 focus:border-violet-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="city" className="text-gray-900">Ciudad</Label>
                  <Input
                    id="city"
                    type="text"
                    placeholder="Tu ciudad"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    required
                    className="border-2 border-gray-200 focus:border-violet-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-gray-900">Teléfono</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="Tu teléfono"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                    className="border-2 border-gray-200 focus:border-violet-600"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="role" className="text-gray-900">¿Querés colaborar como?</Label>
                  <Select onValueChange={(value) => setFormData({ ...formData, role: value })}>
                    <SelectTrigger className="border-2 border-gray-200 focus:border-violet-600">
                      <SelectValue placeholder="Seleccioná una opción" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="difusion">Difusión</SelectItem>
                      <SelectItem value="voluntario">Voluntario</SelectItem>
                      <SelectItem value="fiscal">Fiscal</SelectItem>
                      <SelectItem value="logistica">Logística</SelectItem>
                      <SelectItem value="redes">Redes Sociales</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button type="submit" className="w-full bg-violet-600 hover:bg-violet-700 text-white text-lg py-6">
                  Enviar Formulario
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
